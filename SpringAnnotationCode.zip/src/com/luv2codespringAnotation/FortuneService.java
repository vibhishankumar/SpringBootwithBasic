package com.luv2codespringAnotation;

public interface FortuneService {
	public String getdailyFortune();

}
