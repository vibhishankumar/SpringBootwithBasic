package com.luv2codespringAnotation;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class RandomFortuneService implements FortuneService {
	//Creating An array of String
	String data[]= {
			"here is RandomFortuneServices",
			"Today is your lucky day",
			"Just Enjoye your days"
	};
    //Creating Random Number Generator
	private Random myRandom=new Random();
	@Override
	public String getdailyFortune() {
		// TODO Auto-generated method stub
		int index=myRandom.nextInt(data.length);
		String theFortune=data[index];
		return theFortune;
	}

}
