package com.luv2codespringAnotation;

import org.springframework.stereotype.Component;

@Component
public class DataBaseFortune implements FortuneService {

	@Override
	public String getdailyFortune() {
		// TODO Auto-generated method stub
		return null;
	}

}
