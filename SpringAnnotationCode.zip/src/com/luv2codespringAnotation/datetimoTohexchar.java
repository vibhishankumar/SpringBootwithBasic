package com.luv2codespringAnotation;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;

public class datetimoTohexchar {
	public static void p(Object o)
	{
		System.out.println(o);
	}

	public static void main(String[] args) throws UnsupportedEncodingException, ParseException {
		    LocalDateTime dl=LocalDateTime.now();
		    LocalDateTime hire=LocalDateTime.of(2018, 10, 21, 5, 23, 45);
		    System.out.println(hire);
		    DateTimeFormatter df= DateTimeFormatter.ofPattern("YYYY/MM/DD@HH:MM:SS");
		    System.out.println(hire.format(df));
		    
		    
		    Date d=new Date();
		    System.out.println(d);
		    SimpleDateFormat sdf = new SimpleDateFormat("DDMMYYYY");
		    System.out.println(Integer.parseInt(sdf.format(d)));
		   int res=Integer.parseInt(sdf.format(d));
		    System.out.println(Integer.toHexString(res));
		   // Integer.parse
		    
		    
		   /* String userdate="28032018";
		    Date d1=sdf.parse(userdate);
		    System.out.println(sdf.format(d1));
		    System.out.println(Integer.parseInt(sdf.format(d1)));
		    
		    */
		   
		    //SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
		   // String strDate = formatter.format(dd);
		    Date dd=new Date();
		    SimpleDateFormat  formatter = new SimpleDateFormat("ddMMyyyyhhmmss");  
		    String strDate = formatter.format(dd);  
		    System.out.println("Date Format with dd-M-yyyy hh:mm:ss : "+strDate);
		    Long res1=Long.parseLong(formatter.format(dd));
		    System.out.println(res1);
		    System.out.println(Long.toHexString(res1));
		    
		    
	}
}
