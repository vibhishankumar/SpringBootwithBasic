package com.luv2codespringAnotation;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotationDemoEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//read spring config file
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//get the bean from spring container
		Coach thecoach=context.getBean("tanishCoach", Coach.class);
		
		//call method on bean
		System.out.println(thecoach.getDailyWorkOut());
		//use some method
		System.out.println(thecoach.getWailyFortune());
		
		//close the context
		context.close();

	}

}
