package com.luv2codespringAnotation;

public interface Coach {
	public String getDailyWorkOut();
	public String getWailyFortune();

}
