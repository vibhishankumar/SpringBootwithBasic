package com.luv2codespringAnotation;

//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class HappyFortuneService implements FortuneService {

	@Override
	public String getdailyFortune() {
		// TODO Auto-generated method stub
		return "It not always lucky !";
	}

}
