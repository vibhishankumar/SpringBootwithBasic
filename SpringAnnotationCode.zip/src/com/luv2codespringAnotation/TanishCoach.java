package com.luv2codespringAnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class TanishCoach implements Coach {
	/*@Autowired
	@Qualifier("randomFortuneService")*/
	private FortuneService fortuneService;
	public TanishCoach()
	{
		System.out.println(">>Inside tanishCoach ");
	}
	/*
	 * In case of Constructor
	 *  You have to place the @Qualifier annotation inside of the constructor arguments. 
	 */
	@Autowired
    public TanishCoach(@Qualifier("randomFortuneService") FortuneService theFortuneService) {

        System.out.println(">> TennisCoach: inside constructor using @autowired and @qualifier");
        
        fortuneService = theFortuneService;
    }
	/*@Autowired
	public TanishCoach(FortuneService thefortuneService)
	{
		//this.fortuneService=thefortuneService;
	}*/
	/*@Autowired
	public void setterFortune(FortuneService thfortuneservice)
	{
		System.out.println(">>Inside tanishCoach setter method() ");
		this.fortuneService=thfortuneservice;
	}
	*/

	@Override
	public String getDailyWorkOut() {
		// TODO Auto-generated method stub
		//("thatSillyCoach") if component not specified by any bean Id then if will be accessed by default
		//bean Id as class name
		return "prectice daily vollyball";
	}

	@Override
	public String getWailyFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getdailyFortune();
	}

}
